# Positron (+)  

###### Este material é ficticio desenvolvido para trabalho da faculdade Impacta FIT.

>***A empresa Positron Plus desenvolveu um sistema de voo com carros sofisticados nomeados de***  
>***Electrons por USD $ 3.99 por pessoa com um limite de quatro passageiros por viagem.***  


#### O sistema realiza a liberação de carros voadores  
#### por meios de tickets eletronicos fornecidos por qrcode.  

![Eletrons](https://adrenaline.com.br/admin/files/sysmidia/7ZD04ZaZZAb41DBAx08cZ6BAB9bDDC/carro-voador_aberta.jpg)
